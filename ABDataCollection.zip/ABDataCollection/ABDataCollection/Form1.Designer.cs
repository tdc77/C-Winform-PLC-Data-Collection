﻿namespace ABDataCollection
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            dataGridView1 = new DataGridView();
            dateTimePicker1 = new DateTimePicker();
            tb1 = new TextBox();
            tb2 = new TextBox();
            tb3 = new TextBox();
            tb4 = new TextBox();
            tb5 = new TextBox();
            tb6 = new TextBox();
            tb7 = new TextBox();
            tbIPaddress = new TextBox();
            tbStatus = new TextBox();
            timer1 = new System.Windows.Forms.Timer(components);
            SecTimer = new System.Windows.Forms.Timer(components);
            tbInterval = new TextBox();
            tb8 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            lblTb1 = new Label();
            lbltb2 = new Label();
            btnSetParam = new Button();
            lbltb3 = new Label();
            lbltb4 = new Label();
            lbltb5 = new Label();
            lbltb6 = new Label();
            lbltb7 = new Label();
            lbltb8 = new Label();
            panel2 = new Panel();
            tbarraylength = new TextBox();
            lblarraylength = new Label();
            label4 = new Label();
            tbtagname = new TextBox();
            cbstring = new CheckBox();
            cbDint = new CheckBox();
            panel1 = new Panel();
            cmbtextbox = new ComboBox();
            tbNames = new TextBox();
            lblColumnNames = new Label();
            lblColNames = new Label();
            btnColName = new Button();
            tb9 = new TextBox();
            lbltb9 = new Label();
            cbdate = new CheckBox();
            button1 = new Button();
            label5 = new Label();
            openFileDialog1 = new OpenFileDialog();
            tbPath = new TextBox();
            btnExcelPath = new Button();
            folderBrowserDialog1 = new FolderBrowserDialog();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.GrayText;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(220, 310);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(1487, 353);
            dataGridView1.TabIndex = 0;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            dateTimePicker1.Location = new Point(1543, 19);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(200, 23);
            dateTimePicker1.TabIndex = 1;
            // 
            // tb1
            // 
            tb1.Location = new Point(228, 281);
            tb1.Name = "tb1";
            tb1.Size = new Size(100, 23);
            tb1.TabIndex = 2;
            // 
            // tb2
            // 
            tb2.Location = new Point(359, 281);
            tb2.Name = "tb2";
            tb2.Size = new Size(100, 23);
            tb2.TabIndex = 3;
            // 
            // tb3
            // 
            tb3.Location = new Point(494, 281);
            tb3.Name = "tb3";
            tb3.Size = new Size(100, 23);
            tb3.TabIndex = 4;
            // 
            // tb4
            // 
            tb4.Location = new Point(622, 281);
            tb4.Name = "tb4";
            tb4.Size = new Size(100, 23);
            tb4.TabIndex = 5;
            // 
            // tb5
            // 
            tb5.Location = new Point(748, 281);
            tb5.Name = "tb5";
            tb5.Size = new Size(100, 23);
            tb5.TabIndex = 6;
            // 
            // tb6
            // 
            tb6.Location = new Point(874, 281);
            tb6.Name = "tb6";
            tb6.Size = new Size(100, 23);
            tb6.TabIndex = 7;
            tb6.TextChanged += TextBox_TextChanged;
            // 
            // tb7
            // 
            tb7.Location = new Point(1001, 281);
            tb7.Name = "tb7";
            tb7.Size = new Size(100, 23);
            tb7.TabIndex = 8;
            // 
            // tbIPaddress
            // 
            tbIPaddress.Location = new Point(114, 28);
            tbIPaddress.Name = "tbIPaddress";
            tbIPaddress.Size = new Size(152, 23);
            tbIPaddress.TabIndex = 9;
            // 
            // tbStatus
            // 
            tbStatus.Location = new Point(114, 70);
            tbStatus.Name = "tbStatus";
            tbStatus.Size = new Size(100, 23);
            tbStatus.TabIndex = 10;
            // 
            // timer1
            // 
            timer1.Interval = 1000;
            timer1.Tick += Timer1_Tick;
            // 
            // SecTimer
            // 
            SecTimer.Enabled = true;
            SecTimer.Interval = 1000;
            SecTimer.Tick += SecTimer_Tick;
            // 
            // tbInterval
            // 
            tbInterval.Location = new Point(114, 114);
            tbInterval.Name = "tbInterval";
            tbInterval.Size = new Size(100, 23);
            tbInterval.TabIndex = 11;
            // 
            // tb8
            // 
            tb8.Location = new Point(1130, 281);
            tb8.Name = "tb8";
            tb8.Size = new Size(100, 23);
            tb8.TabIndex = 12;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(21, 32);
            label1.Name = "label1";
            label1.Size = new Size(85, 16);
            label1.TabIndex = 13;
            label1.Text = "IPADDRESS:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(45, 73);
            label2.Name = "label2";
            label2.Size = new Size(61, 16);
            label2.TabIndex = 14;
            label2.Text = "STATUS:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(9, 117);
            label3.Name = "label3";
            label3.Size = new Size(100, 16);
            label3.TabIndex = 15;
            label3.Text = "INTERVAL(ms):";
            // 
            // lblTb1
            // 
            lblTb1.AutoSize = true;
            lblTb1.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTb1.Location = new Point(249, 254);
            lblTb1.Name = "lblTb1";
            lblTb1.Size = new Size(50, 16);
            lblTb1.TabIndex = 16;
            lblTb1.Text = "Value1";
            // 
            // lbltb2
            // 
            lbltb2.AutoSize = true;
            lbltb2.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbltb2.Location = new Point(380, 256);
            lbltb2.Name = "lbltb2";
            lbltb2.Size = new Size(50, 16);
            lbltb2.TabIndex = 17;
            lbltb2.Text = "Value2";
            // 
            // btnSetParam
            // 
            btnSetParam.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSetParam.Location = new Point(1274, 22);
            btnSetParam.Name = "btnSetParam";
            btnSetParam.Size = new Size(116, 42);
            btnSetParam.TabIndex = 18;
            btnSetParam.Text = "START LOGGING";
            btnSetParam.UseVisualStyleBackColor = true;
            btnSetParam.Click += BtnSetParam_Click;
            // 
            // lbltb3
            // 
            lbltb3.AutoSize = true;
            lbltb3.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbltb3.Location = new Point(514, 255);
            lbltb3.Name = "lbltb3";
            lbltb3.Size = new Size(50, 16);
            lbltb3.TabIndex = 19;
            lbltb3.Text = "Value3";
            // 
            // lbltb4
            // 
            lbltb4.AutoSize = true;
            lbltb4.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbltb4.Location = new Point(642, 256);
            lbltb4.Name = "lbltb4";
            lbltb4.Size = new Size(50, 16);
            lbltb4.TabIndex = 20;
            lbltb4.Text = "Value4";
            // 
            // lbltb5
            // 
            lbltb5.AutoSize = true;
            lbltb5.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbltb5.Location = new Point(768, 256);
            lbltb5.Name = "lbltb5";
            lbltb5.Size = new Size(50, 16);
            lbltb5.TabIndex = 21;
            lbltb5.Text = "Value5";
            // 
            // lbltb6
            // 
            lbltb6.AutoSize = true;
            lbltb6.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbltb6.Location = new Point(895, 254);
            lbltb6.Name = "lbltb6";
            lbltb6.Size = new Size(50, 16);
            lbltb6.TabIndex = 22;
            lbltb6.Text = "Value6";
            // 
            // lbltb7
            // 
            lbltb7.AutoSize = true;
            lbltb7.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbltb7.Location = new Point(1020, 254);
            lbltb7.Name = "lbltb7";
            lbltb7.Size = new Size(50, 16);
            lbltb7.TabIndex = 23;
            lbltb7.Text = "Value7";
            // 
            // lbltb8
            // 
            lbltb8.AutoSize = true;
            lbltb8.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbltb8.Location = new Point(1148, 255);
            lbltb8.Name = "lbltb8";
            lbltb8.Size = new Size(50, 16);
            lbltb8.TabIndex = 24;
            lbltb8.Text = "Value8";
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.Highlight;
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(tbInterval);
            panel2.Controls.Add(tbStatus);
            panel2.Controls.Add(tbIPaddress);
            panel2.Location = new Point(12, 12);
            panel2.Name = "panel2";
            panel2.Size = new Size(304, 205);
            panel2.TabIndex = 32;
            // 
            // tbarraylength
            // 
            tbarraylength.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbarraylength.Location = new Point(114, 54);
            tbarraylength.Name = "tbarraylength";
            tbarraylength.Size = new Size(39, 21);
            tbarraylength.TabIndex = 25;
            // 
            // lblarraylength
            // 
            lblarraylength.AutoSize = true;
            lblarraylength.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblarraylength.Location = new Point(16, 56);
            lblarraylength.Name = "lblarraylength";
            lblarraylength.Size = new Size(93, 16);
            lblarraylength.TabIndex = 26;
            lblarraylength.Text = "Array Length:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(4, 14);
            label4.Name = "label4";
            label4.Size = new Size(105, 16);
            label4.TabIndex = 27;
            label4.Text = "TagArrayName:";
            // 
            // tbtagname
            // 
            tbtagname.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbtagname.Location = new Point(114, 11);
            tbtagname.Name = "tbtagname";
            tbtagname.Size = new Size(176, 21);
            tbtagname.TabIndex = 28;
            // 
            // cbstring
            // 
            cbstring.AutoSize = true;
            cbstring.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cbstring.Location = new Point(321, 11);
            cbstring.Name = "cbstring";
            cbstring.Size = new Size(60, 19);
            cbstring.TabIndex = 29;
            cbstring.Text = "String";
            cbstring.UseVisualStyleBackColor = true;
            // 
            // cbDint
            // 
            cbDint.AutoSize = true;
            cbDint.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cbDint.Location = new Point(322, 39);
            cbDint.Name = "cbDint";
            cbDint.Size = new Size(48, 19);
            cbDint.TabIndex = 30;
            cbDint.Text = "Dint";
            cbDint.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.AppWorkspace;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(cbDint);
            panel1.Controls.Add(cbstring);
            panel1.Controls.Add(tbtagname);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(lblarraylength);
            panel1.Controls.Add(tbarraylength);
            panel1.Location = new Point(380, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(397, 89);
            panel1.TabIndex = 31;
            // 
            // cmbtextbox
            // 
            cmbtextbox.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cmbtextbox.FormattingEnabled = true;
            cmbtextbox.Items.AddRange(new object[] { "Value1", "Value2", "Value3", "Value4", "Value5", "Value6", "Value7", "Value8", "Value9" });
            cmbtextbox.Location = new Point(748, 185);
            cmbtextbox.MaxDropDownItems = 10;
            cmbtextbox.Name = "cmbtextbox";
            cmbtextbox.Size = new Size(121, 23);
            cmbtextbox.TabIndex = 33;
            // 
            // tbNames
            // 
            tbNames.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tbNames.Location = new Point(942, 187);
            tbNames.Name = "tbNames";
            tbNames.Size = new Size(160, 21);
            tbNames.TabIndex = 34;
            // 
            // lblColumnNames
            // 
            lblColumnNames.AutoSize = true;
            lblColumnNames.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblColumnNames.Location = new Point(682, 187);
            lblColumnNames.Name = "lblColumnNames";
            lblColumnNames.Size = new Size(60, 16);
            lblColumnNames.TabIndex = 35;
            lblColumnNames.Text = "Column:";
            // 
            // lblColNames
            // 
            lblColNames.AutoSize = true;
            lblColNames.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblColNames.Location = new Point(889, 189);
            lblColNames.Name = "lblColNames";
            lblColNames.Size = new Size(48, 16);
            lblColNames.TabIndex = 36;
            lblColNames.Text = "Name:";
            // 
            // btnColName
            // 
            btnColName.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnColName.Location = new Point(1109, 174);
            btnColName.Name = "btnColName";
            btnColName.Size = new Size(89, 43);
            btnColName.TabIndex = 37;
            btnColName.Text = "SET NAME";
            btnColName.UseVisualStyleBackColor = true;
            btnColName.Click += BtnColName_Click;
            // 
            // tb9
            // 
            tb9.Location = new Point(1256, 281);
            tb9.Name = "tb9";
            tb9.Size = new Size(100, 23);
            tb9.TabIndex = 38;
            // 
            // lbltb9
            // 
            lbltb9.AutoSize = true;
            lbltb9.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbltb9.Location = new Point(1274, 254);
            lbltb9.Name = "lbltb9";
            lbltb9.Size = new Size(50, 16);
            lbltb9.TabIndex = 39;
            lbltb9.Text = "Value9";
            // 
            // cbdate
            // 
            cbdate.AutoSize = true;
            cbdate.Location = new Point(1469, 281);
            cbdate.Name = "cbdate";
            cbdate.Size = new Size(136, 19);
            cbdate.TabIndex = 40;
            cbdate.Text = "Last Column as date.";
            cbdate.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(1402, 22);
            button1.Name = "button1";
            button1.Size = new Size(116, 42);
            button1.TabIndex = 41;
            button1.Text = "STOP LOGGING";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(1274, 187);
            label5.Name = "label5";
            label5.Size = new Size(91, 16);
            label5.TabIndex = 42;
            label5.Text = "Excel Folder:";
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // tbPath
            // 
            tbPath.Location = new Point(1371, 182);
            tbPath.Name = "tbPath";
            tbPath.Size = new Size(339, 23);
            tbPath.TabIndex = 43;
            // 
            // btnExcelPath
            // 
            btnExcelPath.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnExcelPath.Location = new Point(1371, 130);
            btnExcelPath.Name = "btnExcelPath";
            btnExcelPath.Size = new Size(109, 40);
            btnExcelPath.TabIndex = 44;
            btnExcelPath.Text = "SET FOLDER";
            btnExcelPath.UseVisualStyleBackColor = true;
            btnExcelPath.Click += btnExcelPath_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SlateGray;
            ClientSize = new Size(1755, 831);
            Controls.Add(btnExcelPath);
            Controls.Add(tbPath);
            Controls.Add(label5);
            Controls.Add(button1);
            Controls.Add(cbdate);
            Controls.Add(lbltb9);
            Controls.Add(tb9);
            Controls.Add(btnColName);
            Controls.Add(lblColNames);
            Controls.Add(lblColumnNames);
            Controls.Add(tbNames);
            Controls.Add(cmbtextbox);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(lbltb8);
            Controls.Add(lbltb7);
            Controls.Add(lbltb6);
            Controls.Add(lbltb5);
            Controls.Add(lbltb4);
            Controls.Add(lbltb3);
            Controls.Add(btnSetParam);
            Controls.Add(lbltb2);
            Controls.Add(lblTb1);
            Controls.Add(tb8);
            Controls.Add(tb7);
            Controls.Add(tb6);
            Controls.Add(tb5);
            Controls.Add(tb4);
            Controls.Add(tb3);
            Controls.Add(tb2);
            Controls.Add(tb1);
            Controls.Add(dateTimePicker1);
            Controls.Add(dataGridView1);
            Name = "Form1";
            Text = "11";
            WindowState = FormWindowState.Maximized;
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private DateTimePicker dateTimePicker1;
        private TextBox tb1;
        private TextBox tb2;
        private TextBox tb3;
        private TextBox tb4;
        private TextBox tb5;
        private TextBox tb6;
        private TextBox tb7;
        private TextBox tbIPaddress;
        private TextBox tbStatus;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer SecTimer;
        private TextBox tbInterval;
        private TextBox tb8;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label lblTb1;
        private Label lbltb2;
        private Button btnSetParam;
        private Label lbltb3;
        private Label lbltb4;
        private Label lbltb5;
        private Label lbltb6;
        private Label lbltb7;
        private Label lbltb8;
        private Panel panel2;
        private TextBox tbarraylength;
        private Label lblarraylength;
        private Label label4;
        private TextBox tbtagname;
        private CheckBox cbstring;
        private CheckBox cbDint;
        private Panel panel1;
        private ComboBox cmbtextbox;
        private TextBox tbNames;
        private Label lblColumnNames;
        private Label lblColNames;
        private Button btnColName;
        private TextBox tb9;
        private Label lbltb9;
        private CheckBox cbdate;
        private Button button1;
        private Label label5;
        private OpenFileDialog openFileDialog1;
        private TextBox tbPath;
        private Button btnExcelPath;
        private FolderBrowserDialog folderBrowserDialog1;
    }
}