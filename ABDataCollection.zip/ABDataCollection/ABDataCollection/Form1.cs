﻿using ClosedXML.Excel;
using libplctag.DataTypes;
using libplctag;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Threading.Tasks;
using System.Windows.Forms;
using libplctag.DataTypes.Simple;



///TODO: Add functionality to read continious or read only on tb changed value. Also to add date at end or not.

namespace ABDataCollection
{
    public partial class Form1 : Form
    {
        public bool DataAck = false; //ack to plc that data was read
        //public int Sending = 0;//sending email
        public bool CanRead = true; // data is ready from plc
        public bool InAuto = false;// only read from plc if machine is in auto
        public bool TextWasChanged = false;
        //where is file to be saved save by date!!
       // public string fileName;
        public string IPaddress = "";
        public string Interval = "";
        
        public Form1()
        {
            InitializeComponent();
            timer1 = new System.Windows.Forms.Timer();
            timer1.Tick += new EventHandler(Timer1_Tick);
            timer1.Enabled = false; // Make sure it's disabled initially
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //add_Columns();

        }

        public static class GlobalVariables
        {
            public static string fileName { get; set; } = string.Empty;
           
        }

        private void Timer1_Tick(object? sender, EventArgs e)
        {
            try
            {
                // Check connection  
                System.Net.NetworkInformation.Ping pingSender = new();
                System.Net.NetworkInformation.PingOptions options = new System.Net.NetworkInformation.PingOptions();
                int timeout = 1000;
                System.Net.NetworkInformation.PingReply reply = pingSender.Send(IPaddress, timeout);

                if (reply.Status == System.Net.NetworkInformation.IPStatus.Success)
                {
                    tbStatus.ForeColor = System.Drawing.Color.Green;
                    tbStatus.Text = "Connected";
                    PLCGetData();
                }
                else
                {
                    // Connection failed  
                    tbStatus.ForeColor = System.Drawing.Color.Red;
                    tbStatus.Text = "Not Connected";
                    TimedMessageBox.Show("Cannot connect to PLC", "ERROR", 2000);
                }
            }
            catch (Exception ex)
            {
                tbStatus.ForeColor = System.Drawing.Color.Red;
                tbStatus.Text = $"Error: {ex.Message}";
                timer1.Stop(); // Stop the timer on exception  
            }

            // Check if camera barcode changed in textbox, if so write to excel sheet  
            if (TextWasChanged == true)
            {
                WritetoDGView();
            }
        }

        //Timer that ticks every second use for time and other functions
        //that need to fire at a exact given time.
        private void SecTimer_Tick(object sender, EventArgs e)
        {

            try
            {

                TimeSpan time = DateTime.Now.TimeOfDay;

                //create a new file at 12am 

                if (DateTime.Now.Hour == 0 && DateTime.Now.Minute == 0 && DateTime.Now.Second == 2)
                {
                    dataGridView1.Rows.Clear();

                    CreateExcel();

                }

            }
            catch (Exception)
            {
                TimedMessageBox.Show("Cant connect to PLC", "ERROR", 2000);
            }

        }

        //Add other column name here that need to be added to sheet.
        private void add_Columns()
        {
            //setup the columns to be added if more are needed change this number to amount of columns!!
            dataGridView1.ColumnCount = 9;
            //Set the columns Width and Name.
            dataGridView1.Columns[0].Name = lblTb1.Text.ToString();
            dataGridView1.Columns[0].Width = 100;
            dataGridView1.Columns[1].Name = lbltb2.Text.ToString();
            dataGridView1.Columns[1].Width = 100;
            dataGridView1.Columns[2].Name = lbltb3.Text.ToString();
            dataGridView1.Columns[2].Width = 100;
            dataGridView1.Columns[3].Name = lbltb4.Text.ToString();
            dataGridView1.Columns[3].Width = 100;
            dataGridView1.Columns[4].Name = lbltb5.Text.ToString();
            dataGridView1.Columns[4].Width = 100;
            dataGridView1.Columns[5].Name = lbltb6.Text.ToString();
            dataGridView1.Columns[5].Width = 100;
            dataGridView1.Columns[6].Name = lbltb7.Text.ToString();
            dataGridView1.Columns[6].Width = 150;
            dataGridView1.Columns[7].Name = lbltb8.Text.ToString();
            dataGridView1.Columns[7].Width = 205;
            bool addDateTimeColumn = cbdate.Checked;
            if (addDateTimeColumn)
            {

                dataGridView1.Columns[8].Name = "Date/Time";
                dataGridView1.Columns[8].Width = 275;
            }
        }

        //Get data from textboxes and insert into Gridview and Excel
        public DataTable getData()
        {
            DataTable dt = new DataTable();

            // Adding columns dynamically based on checkbox selection
            dt.Columns.Add(lblTb1.Text.ToString(), typeof(string));
            dt.Columns.Add(lbltb2.Text.ToString(), typeof(string));
            dt.Columns.Add(lbltb3.Text.ToString(), typeof(string));
            dt.Columns.Add(lbltb4.Text.ToString(), typeof(string));
            dt.Columns.Add(lbltb5.Text.ToString(), typeof(string));
            dt.Columns.Add(lbltb6.Text.ToString(), typeof(string));
            dt.Columns.Add(lbltb7.Text.ToString(), typeof(string));
            dt.Columns.Add(lbltb8.Text.ToString(), typeof(string));

            bool addDateTimeColumn = cbdate.Checked;
            if (addDateTimeColumn)
            {
                dt.Columns.Add("Date/Time", typeof(DateTime));
            }

            // Create a list to hold row values dynamically
            List<object> rowData = new List<object>
    {
             tb1.Text.ToString(),
             tb2.Text.ToString(),
             tb3.Text.ToString(),
             tb4.Text.ToString(),
             tb5.Text.ToString(),
             tb6.Text.ToString(),
             tb7.Text.ToString(),
             tb8.Text.ToString()
    };

            // Conditionally add DateTime if the checkbox is checked
            if (addDateTimeColumn)
            {
                rowData.Add(DateTime.Now);
            }

            // Add the row using the dynamic list
            dt.Rows.Add(rowData.ToArray());

            return dt;
        }



        //Create excel sheet if it doesnt exsist.
        public void CreateExcel()
        {
            try
            {
                {
                    GlobalVariables.fileName = tbPath.Text.Replace("\\", "\\\\");

                    string fileName = GlobalVariables.fileName + "\\" + DateTime.Today.ToString("yyyyMMdd") + ".xlsx";
                    //If file Doesnt exists then create it.
                    if (!File.Exists(fileName))
                    {
                        var wb = new XLWorkbook();
                        var ws = wb.Worksheets.Add(getData(), "MachData"); //Name of excel sheet
                        wb.SaveAs(fileName);
                        wb.Dispose();//free up resources
                        GC.WaitForPendingFinalizers();
                        GC.Collect();
                    }
                }


            }
            //If error occured 
            catch (Exception)
            {
                TimedMessageBox.Show("No File was Made", "ERROR", 2000);
            }

        }

        //The method that writes data to the datagridview.
        public void WritetoDGView()
        {
            DataTable dt = new();
            dt = getData();
            if (TextWasChanged == true)
            {

                try
                {

                    List<object> rowData = new List<object>();

                    // Check each textbox before adding its value
                    if (!string.IsNullOrWhiteSpace(tb1.Text)) rowData.Add(tb1.Text.ToString());
                    if (!string.IsNullOrWhiteSpace(tb2.Text)) rowData.Add(tb2.Text.ToString());
                    if (!string.IsNullOrWhiteSpace(tb3.Text)) rowData.Add(tb3.Text.ToString());
                    if (!string.IsNullOrWhiteSpace(tb4.Text)) rowData.Add(tb4.Text.ToString());
                    if (!string.IsNullOrWhiteSpace(tb5.Text)) rowData.Add(tb5.Text.ToString());
                    if (!string.IsNullOrWhiteSpace(tb6.Text)) rowData.Add(tb6.Text.ToString());
                    if (!string.IsNullOrWhiteSpace(tb7.Text)) rowData.Add(tb7.Text.ToString());
                    if (!string.IsNullOrWhiteSpace(tb8.Text)) rowData.Add(tb8.Text.ToString());



                    if (cbdate.Checked)
                    {
                        rowData.Add(DateTime.Now.ToString());
                    }

                    // Add the row to the DataGridView dynamically
                    if (rowData.Count > 0) // Ensure there's something to add
                    {
                        dataGridView1.Rows.Add(rowData.ToArray());

                        // Now update Excel sheet
                        CreateExcel();
                        UpdateExcel();
                    }
                    else
                    {
                        TimedMessageBox.Show("No valid data to write to GridView", "Warning", 2000);
                    }
                }

                catch (Exception)
                {
                    TimedMessageBox.Show("Cannot write to DGView", "ERROR", 2000);
                }

            }
        }
        //check if texboxes had data changed if so set textwaschanged to true so pc knows
        //to write new data to excel
        private void TextBox_TextChanged(object? sender, EventArgs e)
        {
            TextWasChanged = true;

        }

        private void RegisterTextBoxEvents()
        {
            TextBox[] trackedTextBoxes = { tb1, tb2, tb3, tb4, tb5, tb6, tb7, tb8 };

            foreach (TextBox tb in trackedTextBoxes)
            {
                tb.TextChanged += TextBox_TextChanged;
            }
        }



        void UpdateExcel()
        {

            if (TextWasChanged == true)
            {
                //write data to excel sheet
                WritetoExcel();

                //reset textwaschanged to false so pc doesnt keep writing same data to excel.
                TextWasChanged = false;

            }
            else
            {
                return;
            }
        }

        public void WritetoExcel()
        {
            GlobalVariables.fileName = tbPath.Text.Replace("\\", "\\\\");
            string fileName =  GlobalVariables.fileName + "\\" + DateTime.Today.ToString("yyyyMMdd") + ".xlsx";
           
            try
            {
                CreateExcel();
                DataTable dt = new DataTable();
                //Adding data to exsisiting excel sheet
                {
                    using (XLWorkbook wb = new XLWorkbook(fileName)) 

                    {
                        IXLWorksheet ws = wb.Worksheet("MachData");
                        // Updated code to handle potential null reference for ws.LastRowUsed()
                        int NumberOfLastRow = ws.LastRowUsed()?.RowNumber() ?? 0;
                        IXLCell CellForNewData = ws.Cell(NumberOfLastRow + 1, 1);
                        CellForNewData.InsertData(getData());


                        //Set the color of Header Row.
                        //A resembles First Column while C resembles Third column.
                        wb.Worksheet(1).Cells("A1:H1").Style.Fill.BackgroundColor = XLColor.AirForceBlue;
                        int thisRow = NumberOfLastRow + 1;

                        for (int i = 1; i <= NumberOfLastRow; i++)
                        {
                            string cellRange = string.Format("A{0}:H{0}", i + 1);


                            //Header row is at Position 1 and hence First row starts from Index 2.

                            /*   if (ws.Worksheet.Cell(NumberOfLastRow + 1, 5).Value.ToString() == "PASS" )
                               {

                                   wb.Worksheet(1).Row(thisRow).Style.Fill.BackgroundColor = XLColor.Green;
                               }


                               else
                               {
                                   wb.Worksheet(1).Row(thisRow).Style.Fill.BackgroundColor = XLColor.Red;
                               }*/

                        }

                        //Adjust widths of Columns.
                        wb.Worksheet(1).Columns().AdjustToContents();
                        wb.Worksheet(1).Columns().Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                        //Add DataTable in worksheet

                        using MemoryStream stream = new MemoryStream();

                        wb.SaveAs(fileName);

                        wb.Dispose();//free up resources
                        stream.Close();
                        GC.Collect();//garbage collect
                        GC.WaitForPendingFinalizers();
                        GC.Collect();
                    }

                }


            }
            catch (Exception ex)
            {
                TimedMessageBox.Show($"Error: {ex.Message}", "ERROR", 2000);
            }
        }


        //Read Write Data to PLC Program Here
        public void PLCGetData()

        {
            string ARRAY_LENGTH = tbarraylength.Text.ToString();
            int enteredarray = (int.Parse(ARRAY_LENGTH));
            const int TIMEOUT = 3000;
            const string path = "1,0";
            string Gateway = IPaddress; //tbIPaddress.Text.ToString();
            try
            {
                //If data is ready from PLC then Read it and reset the ready bit.
                var DataReady = new TagBool()//<BoolPlcMapper, bool>

                {
                    Name = "DataSend",
                    Gateway = Gateway,
                    Path = path,
                    Protocol = Protocol.ab_eip,
                    PlcType = PlcType.ControlLogix,

                };
                DataReady.Read();

                CanRead = DataReady.Value;// DataReady.Value;

                if (CanRead == true)
                {
                    //put string data in this array. if more are needed then
                    //lengthen array
                    if (cbstring.Checked == true)
                    {

                        var DataReadPLC = new Tag<StringPlcMapper, string[]>()//<StringPlcMapper, string[,]>()
                        {

                            Name = tbtagname.Text.ToString(),
                            Gateway = Gateway,
                            Path = path,
                            Protocol = Protocol.ab_eip,
                            PlcType = PlcType.ControlLogix,
                            ArrayDimensions = new int[] { enteredarray }, //add more to array if needed do same in plc
                            Timeout = TimeSpan.FromMilliseconds(TIMEOUT),
                        };
                        DataReadPLC.Initialize();
                        DataReadPLC.Read();

                        TextBox[] textBoxes = { tb1, tb2, tb3, tb4, tb5, tb6, tb7, tb8 };

                        for (int i = 0; i < DataReadPLC.Value.Length && i < textBoxes.Length; i++)
                        {
                            textBoxes[i].Text = DataReadPLC.Value[i].ToString();
                        }
                    }
                    else if (cbDint.Checked == true)

                    {

                        var DataDintPLC = new Tag<DintPlcMapper, int[]>()
                        {

                            Name = tbtagname.Text.ToString(),
                            Gateway = Gateway,
                            Path = path,
                            Protocol = Protocol.ab_eip,
                            PlcType = PlcType.ControlLogix,
                            ArrayDimensions = new int[] { enteredarray }, //add more to array if needed do same in plc
                            Timeout = TimeSpan.FromMilliseconds(TIMEOUT),
                        };
                        DataDintPLC.Initialize();
                        DataDintPLC.Read();

                        TextBox[] textBoxesdint = { tb1, tb2, tb3, tb4, tb5, tb6, tb7, tb8 };

                        for (int i = 0; i < DataDintPLC.Value.Length && i < textBoxesdint.Length; i++)
                        {
                            textBoxesdint[i].Text = DataDintPLC.Value[i].ToString();
                        }

                    }
                    //Write Ack to PLC to reset DataRead Bit`
                    var DataAck = new Tag<BoolPlcMapper, bool>
                    {
                        Name = "DataReadFromPLC",//Tag name in PLC we are writing to!!
                        Gateway = Gateway,
                        Path = "1,0",
                        Protocol = Protocol.ab_eip,
                        PlcType = PlcType.ControlLogix,
                        Value = true
                    };
                    DataAck.Write();
                    CanRead = false;
                    Thread.Sleep(800);
                    DataAck.Value = false;
                    DataAck.Write();

                }
                WritetoDGView();
            }
            catch (Exception)
            {
                TimedMessageBox.Show("Connection Timeout", "ERROR", 2000);

            }
        }


        public class TimedMessageBox
        {
            readonly System.Threading.Timer _timeoutTimer;
            readonly string _caption;
            readonly DialogResult _result;
            readonly DialogResult _timerResult;
            bool timedOut = false;

            TimedMessageBox(string text, string caption, int timeout, MessageBoxButtons buttons = MessageBoxButtons.OK, DialogResult timerResult = DialogResult.None)
            {
                _caption = caption;
                _timeoutTimer = new System.Threading.Timer(OnTimerElapsed,
                    null, timeout, System.Threading.Timeout.Infinite);
                _timerResult = timerResult;
                using (_timeoutTimer)
                    _result = MessageBox.Show(text, caption, buttons);
                if (timedOut) _result = _timerResult;
            }

            public static DialogResult Show(string text, string caption, int timeout, MessageBoxButtons buttons = MessageBoxButtons.OK, DialogResult timerResult = DialogResult.None)
            {
                return new TimedMessageBox(text, caption, timeout, buttons, timerResult)._result;
            }

            private void OnTimerElapsed(object? state)
            {
                IntPtr mbWnd = FindWindow("#32770", _caption); // lpClassName is #32770 for MessageBox  
                if (mbWnd != IntPtr.Zero)
                    SendMessage(mbWnd, WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
                _timeoutTimer.Dispose();
                timedOut = true;
            }

            const int WM_CLOSE = 0x0010;
            [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true, CharSet = System.Runtime.InteropServices.CharSet.Auto)]
            static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
            [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
            static extern IntPtr SendMessage(IntPtr hWnd, UInt32 Msg, IntPtr wParam, IntPtr lParam);


        }

        private void BtnSetParam_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tbIPaddress.Text) || string.IsNullOrEmpty(tbInterval.Text))
            {
                TimedMessageBox.Show("Please enter IP Address and Interval", "ERROR", 2000);
                return;
            }

            try
            {
                add_Columns();
                IPaddress = tbIPaddress.Text.ToString();
                Interval = tbInterval.Text.ToString();

                // Parse interval and set timer
                int intervalValue = Int32.Parse(Interval);
                if (intervalValue <= 0)
                {
                    TimedMessageBox.Show("Interval must be greater than zero", "ERROR", 2000);
                    return;
                }

                timer1.Interval = intervalValue;
                timer1.Start();  // Now we start the timer
                SecTimer.Start();

                // Optional: provide user feedback
                tbStatus.Text = "Timer started";
            }
            catch (FormatException)
            {
                TimedMessageBox.Show("Invalid interval format. Please enter a number.", "ERROR", 2000);
            }
            catch (Exception ex)
            {
                TimedMessageBox.Show($"Error: {ex.Message}", "ERROR", 2000);
            }
        }

        private void BtnColName_Click(object sender, EventArgs e)
        {
            //Set names for your columns here
            if (cmbtextbox.SelectedIndex == 0)
                lblTb1.Text = tbNames.Text.ToString();
            if (cmbtextbox.SelectedIndex == 1)
                lbltb2.Text = tbNames.Text.ToString();
            if (cmbtextbox.SelectedIndex == 2)
                lbltb3.Text = tbNames.Text.ToString();
            if (cmbtextbox.SelectedIndex == 3)
                lbltb4.Text = tbNames.Text.ToString();
            if (cmbtextbox.SelectedIndex == 4)
                lbltb5.Text = tbNames.Text.ToString();
            if (cmbtextbox.SelectedIndex == 5)
                lbltb6.Text = tbNames.Text.ToString();
            if (cmbtextbox.SelectedIndex == 6)
                lbltb7.Text = tbNames.Text.ToString();
            if (cmbtextbox.SelectedIndex == 7)
                lbltb8.Text = tbNames.Text.ToString();
            if (cmbtextbox.SelectedIndex == 8)
                lbltb9.Text = tbNames.Text.ToString();

            tbNames.Text = "";//reset name box when done
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Stop(); // Stop the timer when button is clicked
            tbStatus.ForeColor = System.Drawing.Color.Red;
            tbStatus.Text = "Stopped Logging"; // Optional: provide user feedback
        }

        private void btnExcelPath_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog())
            {
                folderBrowserDialog.Description = "Select a folder";
                folderBrowserDialog.ShowNewFolderButton = false; // Allow creating new folders or not

                if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
                {
                    tbPath.Text = folderBrowserDialog.SelectedPath; // Set folder path in TextBox
                    
                }
            }
        }
        
    }
}
